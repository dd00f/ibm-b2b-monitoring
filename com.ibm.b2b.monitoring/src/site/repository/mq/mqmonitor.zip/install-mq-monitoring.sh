#!/bin/sh
#install-cc-monitoring.sh

# to execute remotely : 
# wget -O - http://jute.torolab.ibm.com/mcduffs/monitoring/b2bimon/install-b2bi-monitoring.sh | bash -s (PATH_TO_B2BI)
# example
# wget -O - http://jute.torolab.ibm.com/mcduffs/monitoring/b2bimon/install-b2bi-monitoring.sh | bash -s /sv_team/SI/SI5020500

hostname=`hostname -s`
B2BI_DIR="$1"
B2BI_BIN_DIR="$B2BI_DIR"/bin
B2BI_MON_DIR="$B2BI_DIR"/monitoring
REPOSITORY_URL=http://jute.torolab.ibm.com/mcduffs/monitoring
GRAPHANA_SERVER_NAME=gdhape01.torolab.ibm.com
GRAPHANA_SERVER_PORT=2003

# ensure B2Bi is installed
if [ ! -f "$B2BI_BIN_DIR"/startContainer.sh ]; then
    echo Installation failed. The first parameter didnt match the root directory of B2Bi. Parameter value : "$1"
fi

echo "Downloading Monitoring configuration files"

mkdir "$B2BI_MON_DIR"

wget -q "$REPOSITORY_URL"/b2bimon/jmxtrans-agent-1.0.10-SNAPSHOT.jar -O "$B2BI_MON_DIR"/jmxtrans-agent-1.0.10-SNAPSHOT.jar
wget -q "$REPOSITORY_URL"/b2bimon/jmxtrans-agent-activemq.xml -O "$B2BI_MON_DIR"/jmxtrans-agent-activemq.xml
wget -q "$REPOSITORY_URL"/b2bimon/jmxtrans-agent-b2bi-container.xml -O "$B2BI_MON_DIR"/jmxtrans-agent-b2bi-container.xml
wget -q "$REPOSITORY_URL"/b2bimon/jmxtrans-agent-b2bi-listener.xml -O "$B2BI_MON_DIR"/jmxtrans-agent-b2bi-listener.xml
wget -q "$REPOSITORY_URL"/b2bimon/jmxtrans-agent-b2bi-noapp.xml -O "$B2BI_MON_DIR"/jmxtrans-agent-b2bi-noapp.xml
wget -q "$REPOSITORY_URL"/b2bimon/jmxtrans-agent-b2bi-ops.xml -O "$B2BI_MON_DIR"/jmxtrans-agent-b2bi-ops.xml

echo "Configuring the B2Bi JVM monitoring templates."

sed -i -- s#????#"$hostname"#g "$B2BI_MON_DIR"/jmxtrans-agent-activemq.xml
sed -i -- s#GRAPHANA_SERVER_NAME#"$GRAPHANA_SERVER_NAME"#g "$B2BI_MON_DIR"/jmxtrans-agent-activemq.xml
sed -i -- s#GRAPHANA_SERVER_PORT#"$GRAPHANA_SERVER_PORT"#g "$B2BI_MON_DIR"/jmxtrans-agent-activemq.xml

sed -i -- s#????#"$hostname"#g "$B2BI_MON_DIR"/jmxtrans-agent-b2bi-container.xml
sed -i -- s#GRAPHANA_SERVER_NAME#"$GRAPHANA_SERVER_NAME"#g "$B2BI_MON_DIR"/jmxtrans-agent-b2bi-container.xml
sed -i -- s#GRAPHANA_SERVER_PORT#"$GRAPHANA_SERVER_PORT"#g "$B2BI_MON_DIR"/jmxtrans-agent-b2bi-container.xml

sed -i -- s#????#"$hostname"#g "$B2BI_MON_DIR"/jmxtrans-agent-b2bi-listener.xml
sed -i -- s#GRAPHANA_SERVER_NAME#"$GRAPHANA_SERVER_NAME"#g "$B2BI_MON_DIR"/jmxtrans-agent-b2bi-listener.xml
sed -i -- s#GRAPHANA_SERVER_PORT#"$GRAPHANA_SERVER_PORT"#g "$B2BI_MON_DIR"/jmxtrans-agent-b2bi-listener.xml

sed -i -- s#????#"$hostname"#g "$B2BI_MON_DIR"/jmxtrans-agent-b2bi-noapp.xml
sed -i -- s#GRAPHANA_SERVER_NAME#"$GRAPHANA_SERVER_NAME"#g "$B2BI_MON_DIR"/jmxtrans-agent-b2bi-noapp.xml
sed -i -- s#GRAPHANA_SERVER_PORT#"$GRAPHANA_SERVER_PORT"#g "$B2BI_MON_DIR"/jmxtrans-agent-b2bi-noapp.xml

sed -i -- s#????#"$hostname"#g "$B2BI_MON_DIR"/jmxtrans-agent-b2bi-ops.xml
sed -i -- s#GRAPHANA_SERVER_NAME#"$GRAPHANA_SERVER_NAME"#g "$B2BI_MON_DIR"/jmxtrans-agent-b2bi-ops.xml
sed -i -- s#GRAPHANA_SERVER_PORT#"$GRAPHANA_SERVER_PORT"#g "$B2BI_MON_DIR"/jmxtrans-agent-b2bi-ops.xml


echo "Creating a backup of the B2Bi startup script with the extension : .monitoring.backup"

cp -n "$B2BI_BIN_DIR"/startContainer.sh "$B2BI_BIN_DIR"/startContainer.sh.monitoring.backup
cp -n "$B2BI_BIN_DIR"/startListeners.sh "$B2BI_BIN_DIR"/startListeners.sh.monitoring.backup
cp -n "$B2BI_BIN_DIR"/startActiveMQ.sh "$B2BI_BIN_DIR"/startActiveMQ.sh.monitoring.backup
cp -n "$B2BI_DIR"/noapp/bin/startNoApp.sh "$B2BI_DIR"/noapp/bin/startNoApp.sh.monitoring.backup
cp -n "$B2BI_DIR"/noapp/bin/startContainerNode.sh "$B2BI_DIR"/noapp/bin/startContainerNode.sh.monitoring.backup

echo "Enabling JVM monitoring on B2Bi"


sed -e "s#opsvendor.properties com#opsvendor.properties -Dcom.ibm.logger.performanceLogger.enabled=true -Dcom.ibm.logger.performanceLogger.intervals=1m -javaagent:$B2BI_MON_DIR/jmxtrans-agent-1.0.10-SNAPSHOT.jar=$B2BI_MON_DIR/jmxtrans-agent-b2bi-ops.xml com#g" "$B2BI_BIN_DIR"/startContainer.sh.monitoring.backup > "$B2BI_BIN_DIR"/startContainer.sh
sed -e "s#java \$jvm#java -javaagent:$B2BI_MON_DIR/jmxtrans-agent-1.0.10-SNAPSHOT.jar=$B2BI_MON_DIR/jmxtrans-agent-b2bi-listener.xml \$jvm#g" "$B2BI_BIN_DIR"/startListeners.sh.monitoring.backup > "$B2BI_BIN_DIR"/startListeners.sh
sed -e "s#servers.properties -Dactivemq#servers.properties -javaagent:"$B2BI_MON_DIR"/jmxtrans-agent-1.0.10-SNAPSHOT.jar="$B2BI_MON_DIR"/jmxtrans-agent-activemq.xml -Dactivemq#g" "$B2BI_BIN_DIR"/startActiveMQ.sh.monitoring.backup > "$B2BI_BIN_DIR"/startActiveMQ.sh
sed -e "s#servers.properties -classpath#servers.properties -javaagent:"$B2BI_MON_DIR"/jmxtrans-agent-1.0.10-SNAPSHOT.jar="$B2BI_MON_DIR"/jmxtrans-agent-b2bi-noapp.xml -classpath#g" "$B2BI_DIR"/noapp/bin/startNoApp.sh.monitoring.backup > "$B2BI_DIR"/noapp/bin/startNoApp.sh
sed -e "s#servers.properties -classpath#servers.properties -Dcom.ibm.logger.performanceLogger.enabled=true -Dcom.ibm.logger.performanceLogger.intervals=1m -javaagent:"$B2BI_MON_DIR"/jmxtrans-agent-1.0.10-SNAPSHOT.jar="$B2BI_MON_DIR"/jmxtrans-agent-b2bi-container.xml -classpath#g" "$B2BI_DIR"/noapp/bin/startContainerNode.sh.monitoring.backup > "$B2BI_DIR"/noapp/bin/startContainerNode.sh

echo "B2Bi monitoring configuration completed."

